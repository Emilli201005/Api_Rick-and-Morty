import { FooterContent } from "./styles";


export function Footer(): JSX.Element {
  return (
    <FooterContent>
      <p>Feito por Dieisson Narde</p>
    </FooterContent>
  );
}